import React from "react";
import ReactDOM from "react-dom/client";

function App() {
    return (
    <div>
        <Header />
        <Focaccia />
        <Funghi />
        <Margherita />
        <Prosciutto />
        <Salamino />
        <Spinaci />
    </div>
    );
}

function Header() {
    return <h1>Ashley's Pizza Co.</h1>;
}

function Focaccia() {
    return (
    <div>
      <img src="focaccia.jpg" alt="Focaccia" width="500" />
      <h2>Focaccia</h2>
      <p>Tomato, mozarella, spinach, and ricotta cheese</p>
      <p>$10</p>
    </div>
    );
}

function Funghi() {
    return (
    <div>
      <img src="funghi.jpg" alt="Funghi" width="500" />
      <h2>Funghi</h2>
      <p>Tomato, mozarella, spinach, and ricotta cheese</p>
      <p>$10</p>
    </div>
    );
}

function Margherita() {
    return (
    <div>
      <img src="margherita.jpg" alt="Margherita" width="500" />
      <h2>Margherita</h2>
      <p>Tomato, mozarella, spinach, and ricotta cheese</p>
      <p>$10</p>
    </div>
    );
}

function Prosciutto() {
    return (
    <div>
      <img src="prosciutto.jpg" alt="Prosciutto" width="500" />
      <h2>Prosciutto</h2>
      <p>Tomato, mozarella, spinach, and ricotta cheese</p>
      <p>$10</p>
    </div>
    );
}

function Salamino() {
    return (
    <div>
      <img src="salamino.jpg" alt="Salamino" width="500" />
      <h2>Salamino</h2>
      <p>Tomato, mozarella, spinach, and ricotta cheese</p>
      <p>$10</p>
    </div>
    );
}

function Spinaci() {
    return (
    <div>
      <img src="spinaci.jpg" alt="Spinaci" width="500" />
      <h2>Spinaci</h2>
      <p>Tomato, mozarella, spinach, and ricotta cheese</p>
      <p>$10</p>
    </div>
    );
}


const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);